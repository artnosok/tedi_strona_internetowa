import { Phone, Mail, MapPin } from "lucide-react"

const phoneNumbers = [
  "+48 601 094 565",
  "+48 722 167 779",
  "+48 726 372 597",
]

export function Footer() {
  return (
    <footer className="border-t border-border bg-secondary py-12 lg:py-16">
      <div className="mx-auto max-w-7xl px-4 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10 lg:gap-16">
          {/* Logo & tagline */}
          <div>
            <div className="flex flex-col leading-tight">
              <span className="text-2xl font-bold tracking-tight text-primary">
                TEDI
              </span>
              <span className="text-xs uppercase tracking-widest text-muted-foreground mt-1">
                Remonty & Budowa
              </span>
            </div>
            <p className="mt-4 text-sm text-muted-foreground leading-relaxed">
              Kompleksowe realizacje remontowo-budowlane dla wymagających
              inwestorów.
            </p>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-sm font-semibold uppercase tracking-wider text-foreground mb-4">
              Kontakt
            </h4>
            <div className="flex flex-col gap-3">
              {phoneNumbers.map((phone) => (
                <a
                  key={phone}
                  href={`tel:${phone.replace(/\s/g, "")}`}
                  className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors"
                >
                  <Phone className="h-4 w-4 shrink-0" />
                  {phone}
                </a>
              ))}
              <a
                href="mailto:stefantedi0@gmail.com"
                className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors"
              >
                <Mail className="h-4 w-4 shrink-0" />
                stefantedi0@gmail.com
              </a>
            </div>
          </div>

          {/* Address */}
          <div>
            <h4 className="text-sm font-semibold uppercase tracking-wider text-foreground mb-4">
              Realizacja usług
            </h4>
            <div className="flex flex-col gap-2 text-sm text-muted-foreground">
              <p>Tadeusz Starczewski</p>
              <div className="flex items-center gap-2">
                <MapPin className="h-4 w-4 shrink-0" />
                <span>Ul. 1 Maja 15, 58-100 Świdnica</span>
              </div>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="mt-12 pt-6 border-t border-border">
          <p className="text-center text-xs text-muted-foreground">
            &copy; 2026 TEDI. Wszelkie prawa zastrzeżone.
          </p>
        </div>
      </div>
    </footer>
  )
}
