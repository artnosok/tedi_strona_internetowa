const steps = [
  {
    number: "01",
    title: "Analiza inwestycji",
    description:
      "Dokładna analiza zakresu prac, specyfiki obiektu i oczekiwań inwestora. Wizja lokalna i konsultacje techniczne.",
  },
  {
    number: "02",
    title: "Kosztorys i harmonogram",
    description:
      "Przejrzysty kosztorys z podziałem na etapy oraz szczegółowy harmonogram realizacji uzgodniony z inwestorem.",
  },
  {
    number: "03",
    title: "Realizacja",
    description:
      "Profesjonalna realizacja z bieżącą kontrolą jakości, koordynacją branż i regularnym raportowaniem postępów.",
  },
  {
    number: "04",
    title: "Odbiór i przekazanie",
    description:
      "Końcowy odbiór techniczny, przekazanie dokumentacji i gotowego obiektu. Gwarancja na wykonane prace.",
  },
]

export function Proces() {
  return (
    <section id="proces" className="py-20 lg:py-28 bg-secondary">
      <div className="mx-auto max-w-7xl px-4 lg:px-8">
        {/* Header */}
        <div className="max-w-2xl mx-auto text-center mb-14">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground text-balance">
            Przejrzysty proces od A do Z
          </h2>
        </div>

        {/* Timeline */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {steps.map((step, index) => (
            <div key={step.number} className="relative">
              {/* Connector line for desktop */}
              {index < steps.length - 1 && (
                <div className="hidden lg:block absolute top-10 left-[calc(50%+32px)] right-0 h-px bg-border z-0" />
              )}

              <div className="relative z-10 rounded-lg border border-border bg-card p-6 lg:p-8 h-full flex flex-col">
                <span className="text-4xl lg:text-5xl font-bold text-primary/20">
                  {step.number}
                </span>
                <h3 className="mt-4 text-lg font-semibold text-card-foreground">
                  {step.title}
                </h3>
                <p className="mt-3 text-sm text-muted-foreground leading-relaxed">
                  {step.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
