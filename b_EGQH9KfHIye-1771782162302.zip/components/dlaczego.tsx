import { Moon, FileText, Handshake, CalendarCheck, Users } from "lucide-react"

const features = [
  {
    icon: Moon,
    title: "Realizacja w godzinach nocnych",
    description:
      "Działamy wtedy, kiedy Twój obiekt nie pracuje, minimalizując wpływ na codzienną działalność.",
  },
  {
    icon: FileText,
    title: "Dokumentacja pod dofinansowania",
    description:
      "Przygotowujemy pełną dokumentację niezbędną do uzyskania dofinansowań PFRON i innych programów.",
  },
  {
    icon: Handshake,
    title: "Doświadczenie z instytucjami",
    description:
      "Wieloletnia współpraca z instytucjami publicznymi, bankami i hotelami to nasza specjalizacja.",
  },
  {
    icon: CalendarCheck,
    title: "Terminowość realizacji",
    description:
      "Dotrzymujemy ustalonych terminów. Harmonogram to dla nas zobowiązanie, nie orientacyjna data.",
  },
  {
    icon: Users,
    title: "Własna koordynacja prac",
    description:
      "Pełna organizacja i koordynacja wszystkich ekip i branż z jednego miejsca.",
  },
]

export function Dlaczego() {
  return (
    <section id="dlaczego" className="py-20 lg:py-28 bg-secondary">
      <div className="mx-auto max-w-7xl px-4 lg:px-8">
        {/* Header */}
        <div className="max-w-2xl mx-auto text-center mb-14">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground text-balance">
            Stabilny partner dla Twojej inwestycji
          </h2>
          <p className="mt-4 text-muted-foreground leading-relaxed">
            Nie jesteśmy ekipą od drobnych napraw. Jesteśmy firmą, która
            przejmuje pełną odpowiedzialność za inwestycję.
          </p>
        </div>

        {/* Feature boxes */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature) => (
            <div
              key={feature.title}
              className="group rounded-lg border border-border bg-card p-6 lg:p-8 hover:border-primary/40 transition-all duration-300"
            >
              <div className="flex items-center justify-center h-12 w-12 rounded-lg bg-primary/10 text-primary mb-5 group-hover:bg-primary/20 transition-colors">
                <feature.icon className="h-6 w-6" />
              </div>
              <h3 className="text-lg font-semibold text-card-foreground">
                {feature.title}
              </h3>
              <p className="mt-2 text-sm text-muted-foreground leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
