import { Building2, Landmark, Hotel, Home, Heart } from "lucide-react"

const clients = [
  {
    icon: Building2,
    title: "Deweloperzy",
    description:
      "Wykończenia lokali w stanie deweloperskim, realizacje seryjne i powtarzalne.",
  },
  {
    icon: Landmark,
    title: "Banki i instytucje publiczne",
    description:
      "Remonty oddziałów, adaptacje przestrzeni z zachowaniem norm i procedur.",
  },
  {
    icon: Hotel,
    title: "Hotele i lokale komercyjne",
    description:
      "Realizacje etapowe i nocne, minimalizujące wpływ na funkcjonowanie obiektu.",
  },
  {
    icon: Home,
    title: "Inwestorzy prywatni",
    description:
      "Kompleksowe remonty mieszkań i apartamentów premium pod klucz.",
  },
  {
    icon: Heart,
    title: "Jednostki MOPS / PCPR / PFRON",
    description:
      "Adaptacje dla osób z niepełnosprawnością z pełną dokumentacją do dofinansowań.",
  },
]

export function DlaKogo() {
  return (
    <section id="dla-kogo" className="py-20 lg:py-28 bg-secondary">
      <div className="mx-auto max-w-7xl px-4 lg:px-8">
        {/* Header */}
        <div className="max-w-2xl mx-auto text-center mb-14">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground text-balance">
            Partnerzy, którzy oczekują najwyższej jakości
          </h2>
          <p className="mt-4 text-muted-foreground leading-relaxed">
            Współpracujemy z klientami, którzy cenią punktualność,
            profesjonalizm i pełną odpowiedzialność za realizację.
          </p>
        </div>

        {/* Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {clients.map((client) => (
            <div
              key={client.title}
              className="group rounded-lg border border-border bg-card p-6 lg:p-8 hover:border-primary/40 transition-all duration-300"
            >
              <div className="flex items-center justify-center h-12 w-12 rounded-lg bg-primary/10 text-primary mb-5 group-hover:bg-primary/20 transition-colors">
                <client.icon className="h-6 w-6" />
              </div>
              <h3 className="text-lg font-semibold text-card-foreground">
                {client.title}
              </h3>
              <p className="mt-2 text-sm text-muted-foreground leading-relaxed">
                {client.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
