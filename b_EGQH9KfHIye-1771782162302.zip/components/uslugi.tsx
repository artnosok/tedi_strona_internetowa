import {
  Wrench,
  Bath,
  Building,
  Accessibility,
  Clock,
  CheckCircle2,
} from "lucide-react"

const services = [
  {
    icon: Wrench,
    title: "Kompleksowe remonty mieszkań i lokali komercyjnych",
    description:
      "Pełna koordynacja od projektu po odbiór. Jeden wykonawca, pełna odpowiedzialność.",
    bullets: [
      "Koordynacja wszystkich branż",
      "Jeden punkt kontaktu",
      "Gwarancja jakości",
    ],
  },
  {
    icon: Bath,
    title: "Łazienki pod klucz",
    description:
      "Kompleksowa realizacja łazienek od projektu, przez instalacje, po montaż wyposażenia.",
    bullets: [
      "Projekt i wizualizacja",
      "Hydroizolacja i instalacje",
      "Montaż wyposażenia",
    ],
  },
  {
    icon: Building,
    title: "Realizacje deweloperskie",
    description:
      "Seryjne wykończenia lokali deweloperskich z zachowaniem powtarzalnej jakości.",
    bullets: [
      "Realizacje seryjne",
      "Powtarzalna jakość",
      "Terminowe przekazanie",
    ],
  },
  {
    icon: Accessibility,
    title: "Adaptacje dla osób z niepełnosprawnością",
    description:
      "Pełna adaptacja przestrzeni zgodnie z wymogami PFRON i innych programów.",
    bullets: [
      "Zgodność z wymogami PFRON",
      "Dokumentacja do dofinansowań",
      "Bezbarierowe rozwiązania",
    ],
  },
  {
    icon: Clock,
    title: "Prace nocne i etapowe",
    description:
      "Realizacja prac w trybie nocnym i etapowym, minimalizująca zakłócenia.",
    bullets: [
      "Praca 24/7",
      "Minimalne zakłócenia",
      "Etapowy harmonogram",
    ],
  },
]

export function Uslugi() {
  return (
    <section id="uslugi" className="py-20 lg:py-28">
      <div className="mx-auto max-w-7xl px-4 lg:px-8">
        {/* Header */}
        <div className="max-w-2xl mx-auto text-center mb-14">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground text-balance">
            Pełen zakres usług remontowo-budowlanych
          </h2>
        </div>

        {/* Service cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service) => (
            <div
              key={service.title}
              className="group rounded-lg border border-border bg-card p-6 lg:p-8 hover:border-primary/40 transition-all duration-300 flex flex-col"
            >
              <div className="flex items-center justify-center h-12 w-12 rounded-lg bg-primary/10 text-primary mb-5 group-hover:bg-primary/20 transition-colors">
                <service.icon className="h-6 w-6" />
              </div>
              <h3 className="text-lg font-semibold text-card-foreground">
                {service.title}
              </h3>
              <p className="mt-2 text-sm text-muted-foreground leading-relaxed">
                {service.description}
              </p>
              <ul className="mt-5 flex flex-col gap-2.5 pt-5 border-t border-border/60">
                {service.bullets.map((bullet) => (
                  <li
                    key={bullet}
                    className="flex items-center gap-2 text-sm text-secondary-foreground"
                  >
                    <CheckCircle2 className="h-4 w-4 text-primary shrink-0" />
                    {bullet}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
