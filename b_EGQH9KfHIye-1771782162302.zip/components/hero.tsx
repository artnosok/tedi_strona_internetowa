import { Phone } from "lucide-react"
import Image from "next/image"

const phoneNumbers = [
  "+48 601 094 565",
  "+48 722 167 779",
  "+48 726 372 597",
]

const stats = [
  { value: "500+", label: "Zrealizowanych projektów" },
  { value: "15+", label: "Lat doświadczenia" },
  { value: "100%", label: "Terminowość realizacji" },
]

export function Hero() {
  return (
    <section className="relative min-h-screen flex items-center overflow-hidden">
      {/* Background image */}
      <div className="absolute inset-0">
        <Image
          src="/images/hero-bg.jpg"
          alt="Realizacja remontowo-budowlana"
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-background/90" />
        <div className="absolute inset-0 bg-gradient-to-b from-background/70 via-background/40 to-background" />
      </div>

      <div className="relative z-10 mx-auto max-w-7xl px-4 lg:px-8 pt-28 pb-16 lg:pt-32 lg:pb-20 w-full">
        <div className="max-w-3xl">
          {/* Tag */}
          <div className="inline-flex items-center rounded-full border border-primary/30 bg-card/60 px-4 py-1.5 mb-6">
            <span className="text-xs font-medium text-primary tracking-wide uppercase">
              Kompleksowe inwestycje budowlane
            </span>
          </div>

          {/* Heading */}
          <h1 className="text-3xl md:text-4xl lg:text-5xl xl:text-6xl font-bold leading-tight text-foreground text-balance">
            Kompleksowe realizacje remontowo-budowlane dla wymagających
            inwestorów
          </h1>

          {/* Subtext */}
          <p className="mt-6 text-lg md:text-xl text-muted-foreground leading-relaxed max-w-2xl">
            Od stanu deweloperskiego po wykończenie pod klucz. Terminowo,
            odpowiedzialnie, bez chaosu.
          </p>

          {/* Buttons */}
          <div className="mt-8 flex flex-col sm:flex-row gap-4">
            <a
              href="#kontakt"
              className="inline-flex items-center justify-center rounded-md bg-primary px-8 py-3.5 text-base font-semibold text-primary-foreground hover:bg-primary/90 transition-colors"
            >
              Poproś o wycenę
            </a>
            <a
              href="#kontakt"
              className="inline-flex items-center justify-center rounded-md border border-foreground/30 bg-card/40 px-8 py-3.5 text-base font-semibold text-foreground hover:bg-card/70 hover:border-primary/40 transition-colors"
            >
              Umów rozmowę
            </a>
          </div>

          {/* Phone numbers */}
          <div className="mt-8 flex flex-col sm:flex-row gap-3 sm:gap-6">
            {phoneNumbers.map((phone) => (
              <a
                key={phone}
                href={`tel:${phone.replace(/\s/g, "")}`}
                className="inline-flex items-center gap-2.5 text-lg font-medium text-foreground hover:text-primary transition-colors group"
              >
                <span className="flex items-center justify-center h-9 w-9 rounded-full bg-card text-primary group-hover:bg-card/80 transition-colors">
                  <Phone className="h-4 w-4" />
                </span>
                {phone}
              </a>
            ))}
          </div>
        </div>

        {/* Stats */}
        <div className="mt-16 lg:mt-20 grid grid-cols-1 sm:grid-cols-3 gap-6 lg:gap-8 border-t border-border/60 pt-10">
          {stats.map((stat) => (
            <div key={stat.label} className="text-center sm:text-left">
              <p className="text-3xl lg:text-4xl font-bold text-primary">
                {stat.value}
              </p>
              <p className="mt-1 text-sm text-muted-foreground">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
