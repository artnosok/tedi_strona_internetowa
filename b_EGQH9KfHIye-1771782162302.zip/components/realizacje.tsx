import Image from "next/image"

const projects = [
  {
    image: "/images/project-bathroom.jpg",
    category: "Łazienki pod klucz",
    title: "Łazienka premium",
    description:
      "Kompleksowa realizacja łazienki z wykorzystaniem marmuru i nowoczesnej armatury.",
  },
  {
    image: "/images/project-office.jpg",
    category: "Lokale komercyjne",
    title: "Biuro w centrum Warszawy",
    description:
      "Pełna adaptacja przestrzeni biurowej o powierzchni 400m\u00B2 z podziałem na strefy.",
  },
  {
    image: "/images/project-apartment.jpg",
    category: "Realizacje deweloperskie",
    title: "Osiedle deweloperskie",
    description:
      "Wykończenie 48 mieszkań w stanie deweloperskim z zachowaniem powtarzalnej jakości.",
  },
  {
    image: "/images/project-hotel.jpg",
    category: "Hotele i obiekty komercyjne",
    title: "Lobby hotelowe",
    description:
      "Remont lobby hotelowego realizowany w trybie nocnym bez przerw w działalności hotelu.",
  },
]

export function Realizacje() {
  return (
    <section id="realizacje" className="py-20 lg:py-28">
      <div className="mx-auto max-w-7xl px-4 lg:px-8">
        {/* Header */}
        <div className="max-w-2xl mx-auto text-center mb-14">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground text-balance">
            Wybrane projekty
          </h2>
        </div>

        {/* Project grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {projects.map((project) => (
            <div
              key={project.title}
              className="group rounded-lg border border-border bg-card overflow-hidden hover:border-primary/40 transition-all duration-300"
            >
              <div className="relative aspect-[16/10] overflow-hidden">
                <Image
                  src={project.image}
                  alt={project.title}
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                <div className="absolute bottom-4 left-4">
                  <span className="inline-flex items-center rounded-full bg-primary px-3 py-1 text-xs font-medium text-primary-foreground">
                    {project.category}
                  </span>
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold text-card-foreground">
                  {project.title}
                </h3>
                <p className="mt-2 text-sm text-muted-foreground leading-relaxed">
                  {project.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
