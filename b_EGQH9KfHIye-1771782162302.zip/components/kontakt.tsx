import { Phone, Mail, MapPin, User } from "lucide-react"

const phoneNumbers = [
  "+48 601 094 565",
  "+48 722 167 779",
  "+48 726 372 597",
]

export function Kontakt() {
  return (
    <section id="kontakt" className="py-20 lg:py-28">
      <div className="mx-auto max-w-7xl px-4 lg:px-8">
        {/* Header */}
        <div className="max-w-2xl mx-auto text-center mb-14">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground text-balance">
            Szukasz wykonawcy, który przejmie odpowiedzialność za inwestycję?
          </h2>
          <p className="mt-4 text-muted-foreground leading-relaxed">
            Skontaktuj się z nami bezpośrednio — jesteśmy do Twojej dyspozycji.
          </p>
        </div>

        {/* Contact cards */}
        <div className="max-w-3xl mx-auto">
          {/* Phones + Email grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {phoneNumbers.map((phone) => (
              <a
                key={phone}
                href={`tel:${phone.replace(/\s/g, "")}`}
                className="group flex items-center gap-4 rounded-lg border border-border bg-card p-5 hover:border-primary/60 hover:shadow-[0_0_20px_rgba(13,148,136,0.15)] transition-all duration-300"
              >
                <div className="flex items-center justify-center h-12 w-12 rounded-full bg-secondary text-primary group-hover:bg-accent/30 transition-colors shrink-0">
                  <Phone className="h-5 w-5" />
                </div>
                <div>
                  <p className="text-xs uppercase tracking-wider text-muted-foreground mb-0.5">
                    Telefon
                  </p>
                  <p className="text-lg font-semibold text-card-foreground group-hover:text-primary transition-colors">
                    {phone}
                  </p>
                </div>
              </a>
            ))}

            {/* Email */}
            <a
              href="mailto:stefantedi0@gmail.com"
              className="group flex items-center gap-4 rounded-lg border border-border bg-card p-5 hover:border-primary/60 hover:shadow-[0_0_20px_rgba(13,148,136,0.15)] transition-all duration-300"
            >
              <div className="flex items-center justify-center h-12 w-12 rounded-full bg-primary/15 text-primary group-hover:bg-primary/25 transition-colors shrink-0">
                <Mail className="h-5 w-5" />
              </div>
              <div>
                <p className="text-xs uppercase tracking-wider text-muted-foreground mb-0.5">
                  Email
                </p>
                <p className="text-lg font-semibold text-card-foreground group-hover:text-primary transition-colors">
                  stefantedi0@gmail.com
                </p>
              </div>
            </a>
          </div>

          {/* Address info */}
          <div className="mt-6 rounded-lg border border-border bg-card p-6 lg:p-8">
            <p className="text-xs uppercase tracking-wider text-muted-foreground mb-4">
              Realizacja usług
            </p>
            <div className="flex flex-col gap-3">
              <div className="flex items-center gap-3 text-card-foreground">
                <User className="h-5 w-5 text-primary shrink-0" />
                <span className="font-medium">Tadeusz Starczewski</span>
              </div>
              <div className="flex items-center gap-3 text-card-foreground">
                <MapPin className="h-5 w-5 text-primary shrink-0" />
                <span>Ul. 1 Maja 15, 58-100 Świdnica</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
