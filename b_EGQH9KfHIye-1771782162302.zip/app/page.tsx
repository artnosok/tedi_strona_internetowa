import { Navbar } from "@/components/navbar"
import { Hero } from "@/components/hero"
import { DlaKogo } from "@/components/dla-kogo"
import { Uslugi } from "@/components/uslugi"
import { Dlaczego } from "@/components/dlaczego"
import { Realizacje } from "@/components/realizacje"
import { Proces } from "@/components/proces"
import { Kontakt } from "@/components/kontakt"
import { Footer } from "@/components/footer"

export default function Home() {
  return (
    <>
      <Navbar />
      <main>
        <Hero />
        <DlaKogo />
        <Uslugi />
        <Dlaczego />
        <Realizacje />
        <Proces />
        <Kontakt />
      </main>
      <Footer />
    </>
  )
}
